from django.shortcuts import render
from django.http import HttpResponse
import random
import pyowm
from .models import Task
from django.contrib.auth.models import User

def index(request):
	a=random.randint(1,10)
	#return render(request,)
	return render(request, 'main/index.html')
# Create your views here.

def about(request):
	a=request.GET	
	b=a.getlist('city')
	if len(a)>0:
		owm = pyowm.OWM('8ecfbfed1963b69d1bd880545983f763')
		
		arr=[]
		arr1=[]
		for i in b:
			observation = owm.weather_at_place(i)
			w = observation.get_weather()
			message=w.get_temperature('celsius')['temp']
			arr.append(message)

			time=w.get_reference_time('iso')
			status=w.get_status()
			
		

		return render(request, 'main/index.html', {'country': b,'message': arr, 'time': time, 'status':status})

	else:
		return render(request, 'main/about.html')

# Create your views here.
def home_view(request):
	tasks = Task.objects.order_by('-id')
	return render(request, "main/hello.html", {'tasks': tasks})

def era(request):
	return HttpResponse('<h2>AAAAAAAAAA</h2>')